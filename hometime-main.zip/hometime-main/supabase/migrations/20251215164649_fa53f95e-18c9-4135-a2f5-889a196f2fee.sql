-- Fix memory_comments exposure: restrict SELECT to users who can access the associated memory
DROP POLICY IF EXISTS "Users can view comments" ON public.memory_comments;

CREATE POLICY "Users can view comments on accessible memories"
ON public.memory_comments FOR SELECT
USING (
  memory_id IN (
    SELECT id FROM public.memories 
    WHERE user_id = auth.uid()
    OR family_member_id IN (SELECT public.get_shared_family_member_ids(auth.uid()))
    OR user_id IN (SELECT public.get_connected_user_ids(auth.uid()))
  )
);
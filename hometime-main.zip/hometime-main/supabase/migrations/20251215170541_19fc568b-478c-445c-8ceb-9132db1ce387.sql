-- Create view for admin analytics (security handled by RLS on underlying tables)
CREATE OR REPLACE FUNCTION public.get_admin_analytics()
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  result json;
BEGIN
  -- Only allow admins
  IF NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Access denied';
  END IF;
  
  SELECT json_build_object(
    'total_users', (SELECT COUNT(*) FROM profiles),
    'new_users_today', (SELECT COUNT(*) FROM profiles WHERE created_at >= CURRENT_DATE),
    'new_users_this_week', (SELECT COUNT(*) FROM profiles WHERE created_at >= CURRENT_DATE - INTERVAL '7 days'),
    'new_users_this_month', (SELECT COUNT(*) FROM profiles WHERE created_at >= CURRENT_DATE - INTERVAL '30 days'),
    'active_users_today', (SELECT COUNT(*) FROM profiles WHERE last_login_at >= CURRENT_DATE),
    'active_users_this_month', (SELECT COUNT(*) FROM profiles WHERE last_login_at >= CURRENT_DATE - INTERVAL '30 days'),
    'total_families', (SELECT COUNT(DISTINCT user_id) FROM family_members),
    'total_family_members', (SELECT COUNT(*) FROM family_members),
    'avg_family_size', (SELECT COALESCE(ROUND(AVG(member_count)::numeric, 1), 0) FROM (SELECT user_id, COUNT(*) as member_count FROM family_members GROUP BY user_id) sq),
    'total_memories', (SELECT COUNT(*) FROM memories),
    'memories_with_photos', (SELECT COUNT(*) FROM memories WHERE photo_url IS NOT NULL AND photo_url != ''),
    'memories_text_only', (SELECT COUNT(*) FROM memories WHERE photo_url IS NULL OR photo_url = ''),
    'total_reactions', (SELECT COUNT(*) FROM memory_reactions),
    'total_comments', (SELECT COUNT(*) FROM memory_comments),
    'avg_reactions_per_memory', (SELECT COALESCE(ROUND(COUNT(*)::numeric / NULLIF((SELECT COUNT(*) FROM memories), 0), 1), 0) FROM memory_reactions),
    'avg_comments_per_memory', (SELECT COALESCE(ROUND(COUNT(*)::numeric / NULLIF((SELECT COUNT(*) FROM memories), 0), 1), 0) FROM memory_comments),
    'total_connections', (SELECT COUNT(*) FROM family_connections),
    'total_invitations', (SELECT COUNT(*) FROM family_invitations),
    'pending_invitations', (SELECT COUNT(*) FROM family_invitations WHERE status = 'pending'),
    'accepted_invitations', (SELECT COUNT(*) FROM family_invitations WHERE status = 'accepted')
  ) INTO result;
  
  RETURN result;
END;
$$;

-- Function to get user list for admin (non-sensitive data only)
CREATE OR REPLACE FUNCTION public.get_admin_user_list(
  search_term TEXT DEFAULT NULL,
  page_num INT DEFAULT 1,
  page_size INT DEFAULT 20
)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  result json;
  offset_val INT;
BEGIN
  -- Only allow admins
  IF NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Access denied';
  END IF;
  
  offset_val := (page_num - 1) * page_size;
  
  SELECT json_build_object(
    'users', (
      SELECT json_agg(user_data)
      FROM (
        SELECT 
          p.id,
          p.full_name,
          p.created_at as signup_date,
          p.last_login_at,
          (SELECT COUNT(*) FROM family_members fm WHERE fm.user_id = p.id) as family_members_count,
          (SELECT COUNT(*) FROM memories m WHERE m.user_id = p.id) as memories_count,
          (SELECT COUNT(*) FROM memory_comments mc WHERE mc.user_id = p.id) as comments_count,
          EXISTS(SELECT 1 FROM user_roles ur WHERE ur.user_id = p.id AND ur.role = 'admin') as is_admin
        FROM profiles p
        WHERE (search_term IS NULL OR p.full_name ILIKE '%' || search_term || '%')
        ORDER BY p.created_at DESC
        LIMIT page_size
        OFFSET offset_val
      ) user_data
    ),
    'total_count', (
      SELECT COUNT(*) FROM profiles p
      WHERE (search_term IS NULL OR p.full_name ILIKE '%' || search_term || '%')
    ),
    'page', page_num,
    'page_size', page_size
  ) INTO result;
  
  RETURN result;
END;
$$;

-- Function to check if current user is admin
CREATE OR REPLACE FUNCTION public.is_current_user_admin()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT public.has_role(auth.uid(), 'admin')
$$;
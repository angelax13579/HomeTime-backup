-- Drop the problematic policies
DROP POLICY IF EXISTS "Users can view own or shared family members" ON public.family_members;
DROP POLICY IF EXISTS "Users can view own or shared memories" ON public.memories;
DROP POLICY IF EXISTS "Users can view shared family members" ON public.shared_family_members;
DROP POLICY IF EXISTS "Connected users can insert memories for shared family members" ON public.memories;

-- Create security definer function to check if user has access to a family member
CREATE OR REPLACE FUNCTION public.user_has_family_member_access(_user_id uuid, _family_member_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.family_members 
    WHERE id = _family_member_id AND user_id = _user_id
  )
  OR EXISTS (
    SELECT 1 FROM public.shared_family_members 
    WHERE family_member_id = _family_member_id AND shared_with_user_id = _user_id
  )
$$;

-- Create security definer function to check if user is connected to another user
CREATE OR REPLACE FUNCTION public.users_are_connected(_user_id uuid, _other_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.family_connections 
    WHERE (user_id = _user_id AND connected_user_id = _other_user_id)
       OR (user_id = _other_user_id AND connected_user_id = _user_id)
  )
$$;

-- Create security definer function to get shared family member IDs for a user
CREATE OR REPLACE FUNCTION public.get_shared_family_member_ids(_user_id uuid)
RETURNS SETOF uuid
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT family_member_id FROM public.shared_family_members 
  WHERE shared_with_user_id = _user_id
$$;

-- Create security definer function to get connected user IDs
CREATE OR REPLACE FUNCTION public.get_connected_user_ids(_user_id uuid)
RETURNS SETOF uuid
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT connected_user_id FROM public.family_connections WHERE user_id = _user_id
  UNION
  SELECT user_id FROM public.family_connections WHERE connected_user_id = _user_id
$$;

-- Recreate family_members SELECT policy using the function
CREATE POLICY "Users can view own or shared family members"
ON public.family_members FOR SELECT
USING (
  auth.uid() = user_id 
  OR id IN (SELECT public.get_shared_family_member_ids(auth.uid()))
);

-- Recreate memories SELECT policy using functions
CREATE POLICY "Users can view own or shared memories"
ON public.memories FOR SELECT
USING (
  auth.uid() = user_id
  OR family_member_id IN (SELECT public.get_shared_family_member_ids(auth.uid()))
  OR user_id IN (SELECT public.get_connected_user_ids(auth.uid()))
);

-- Recreate shared_family_members SELECT policy (simpler, no recursion)
CREATE POLICY "Users can view shared family members"
ON public.shared_family_members FOR SELECT
USING (
  auth.uid() = shared_with_user_id
);

-- Update memories INSERT policy
DROP POLICY IF EXISTS "Users can insert own memories" ON public.memories;
CREATE POLICY "Users can insert own memories"
ON public.memories FOR INSERT
WITH CHECK (
  auth.uid() = user_id
  AND (
    EXISTS (SELECT 1 FROM public.family_members WHERE id = family_member_id AND user_id = auth.uid())
    OR family_member_id IN (SELECT public.get_shared_family_member_ids(auth.uid()))
  )
);
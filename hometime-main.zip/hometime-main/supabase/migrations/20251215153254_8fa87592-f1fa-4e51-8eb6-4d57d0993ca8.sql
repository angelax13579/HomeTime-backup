-- Create invitation status enum
CREATE TYPE public.invitation_status AS ENUM ('pending', 'accepted', 'expired');

-- Create family invitations table
CREATE TABLE public.family_invitations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  inviter_user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  family_member_id UUID NOT NULL REFERENCES public.family_members(id) ON DELETE CASCADE,
  invite_code TEXT NOT NULL UNIQUE,
  status invitation_status NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT (now() + interval '7 days'),
  accepted_by_user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  accepted_at TIMESTAMP WITH TIME ZONE
);

-- Create family connections table (links users who share memories)
CREATE TABLE public.family_connections (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  connected_user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  invitation_id UUID NOT NULL REFERENCES public.family_invitations(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, connected_user_id)
);

-- Create shared family members table (tracks which family members are shared between users)
CREATE TABLE public.shared_family_members (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  family_member_id UUID NOT NULL REFERENCES public.family_members(id) ON DELETE CASCADE,
  shared_with_user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  invitation_id UUID NOT NULL REFERENCES public.family_invitations(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(family_member_id, shared_with_user_id)
);

-- Enable RLS
ALTER TABLE public.family_invitations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.family_connections ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.shared_family_members ENABLE ROW LEVEL SECURITY;

-- RLS for family_invitations
CREATE POLICY "Users can view their own invitations"
ON public.family_invitations FOR SELECT
USING (auth.uid() = inviter_user_id OR auth.uid() = accepted_by_user_id);

CREATE POLICY "Users can create invitations for their family members"
ON public.family_invitations FOR INSERT
WITH CHECK (auth.uid() = inviter_user_id);

CREATE POLICY "Users can update their own invitations"
ON public.family_invitations FOR UPDATE
USING (auth.uid() = inviter_user_id);

-- Allow anyone to view pending invitations by code (for accepting)
CREATE POLICY "Anyone can view pending invitation by code"
ON public.family_invitations FOR SELECT
USING (status = 'pending');

-- RLS for family_connections
CREATE POLICY "Users can view their connections"
ON public.family_connections FOR SELECT
USING (auth.uid() = user_id OR auth.uid() = connected_user_id);

CREATE POLICY "Users can create connections"
ON public.family_connections FOR INSERT
WITH CHECK (auth.uid() = user_id OR auth.uid() = connected_user_id);

-- RLS for shared_family_members
CREATE POLICY "Users can view shared family members"
ON public.shared_family_members FOR SELECT
USING (auth.uid() = shared_with_user_id OR auth.uid() IN (
  SELECT user_id FROM public.family_members WHERE id = family_member_id
));

CREATE POLICY "Users can create shared family members"
ON public.shared_family_members FOR INSERT
WITH CHECK (auth.uid() = shared_with_user_id);

-- Update family_members RLS to include shared members
DROP POLICY IF EXISTS "Users can view own family members" ON public.family_members;
CREATE POLICY "Users can view own or shared family members"
ON public.family_members FOR SELECT
USING (
  auth.uid() = user_id 
  OR id IN (SELECT family_member_id FROM public.shared_family_members WHERE shared_with_user_id = auth.uid())
);

-- Update memories RLS to include shared memories
DROP POLICY IF EXISTS "Users can view own memories" ON public.memories;
CREATE POLICY "Users can view own or shared memories"
ON public.memories FOR SELECT
USING (
  auth.uid() = user_id
  OR family_member_id IN (SELECT family_member_id FROM public.shared_family_members WHERE shared_with_user_id = auth.uid())
  OR user_id IN (SELECT connected_user_id FROM public.family_connections WHERE user_id = auth.uid())
  OR user_id IN (SELECT user_id FROM public.family_connections WHERE connected_user_id = auth.uid())
);

-- Allow connected users to insert memories for shared family members
CREATE POLICY "Connected users can insert memories for shared family members"
ON public.memories FOR INSERT
WITH CHECK (
  auth.uid() = user_id
  AND (
    family_member_id IN (SELECT id FROM public.family_members WHERE user_id = auth.uid())
    OR family_member_id IN (SELECT family_member_id FROM public.shared_family_members WHERE shared_with_user_id = auth.uid())
  )
);

-- Create index for faster lookups
CREATE INDEX idx_invitations_code ON public.family_invitations(invite_code);
CREATE INDEX idx_invitations_status ON public.family_invitations(status);
CREATE INDEX idx_connections_user ON public.family_connections(user_id);
CREATE INDEX idx_connections_connected ON public.family_connections(connected_user_id);
CREATE INDEX idx_shared_family_member ON public.shared_family_members(family_member_id);
CREATE INDEX idx_shared_user ON public.shared_family_members(shared_with_user_id);
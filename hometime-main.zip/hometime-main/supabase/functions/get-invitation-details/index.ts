import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { inviteCode } = await req.json();

    // Validate invite code format (UUID format)
    if (!inviteCode || typeof inviteCode !== 'string') {
      console.log('Invalid invite code format: missing or not a string');
      return new Response(
        JSON.stringify({ error: 'Invalid invitation link' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Basic format validation - should be alphanumeric with hyphens (UUID)
    const uuidRegex = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
    if (!uuidRegex.test(inviteCode)) {
      console.log('Invalid invite code format: not a valid UUID');
      return new Response(
        JSON.stringify({ error: 'Invalid invitation link' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Create admin client
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      { auth: { autoRefreshToken: false, persistSession: false } }
    );

    console.log('Fetching invitation details for code:', inviteCode);

    // Fetch invitation with family member details using admin client
    const { data: invitation, error } = await supabaseAdmin
      .from('family_invitations')
      .select(`
        id,
        expires_at,
        status,
        family_members (
          name,
          relation
        )
      `)
      .eq('invite_code', inviteCode)
      .eq('status', 'pending')
      .single();

    if (error || !invitation) {
      console.log('Invitation not found or error:', error?.message);
      return new Response(
        JSON.stringify({ error: 'Invalid invitation link' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check expiration
    if (new Date(invitation.expires_at) < new Date()) {
      console.log('Invitation expired');
      return new Response(
        JSON.stringify({ error: 'This invitation has expired' }),
        { status: 410, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('Invitation found and valid');

    // Return only necessary display information (no sensitive data)
    const familyMember = Array.isArray(invitation.family_members) 
      ? invitation.family_members[0] 
      : invitation.family_members;
    
    return new Response(
      JSON.stringify({
        valid: true,
        familyMemberName: familyMember?.name || 'A family member',
        relation: familyMember?.relation || 'family'
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in get-invitation-details:', error);
    return new Response(
      JSON.stringify({ error: 'Unable to process request' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

// Get allowed origins from environment or use defaults
const getAllowedOrigins = (): string[] => {
  const allowedOrigin = Deno.env.get('ALLOWED_ORIGIN');
  if (allowedOrigin) {
    return allowedOrigin.split(',').map(o => o.trim());
  }
  // Default to common Lovable domains
  return [
    'https://lovable.dev',
    'https://preview--usyakjyrgdqzsbbomcxe.lovable.app',
    'https://usyakjyrgdqzsbbomcxe.lovable.app',
  ];
};

const getCorsHeaders = (req: Request): Record<string, string> => {
  const origin = req.headers.get('Origin') || '';
  const allowedOrigins = getAllowedOrigins();
  
  // Check if origin is allowed
  const isAllowed = allowedOrigins.some(allowed => 
    origin === allowed || 
    origin.endsWith('.lovable.app') || 
    origin.endsWith('.lovable.dev')
  );
  
  return {
    'Access-Control-Allow-Origin': isAllowed ? origin : allowedOrigins[0],
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  };
};

serve(async (req) => {
  const corsHeaders = getCorsHeaders(req);
  
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Fetching daily quote from ZenQuotes API');
    
    // ZenQuotes API - free, no API key required
    const response = await fetch('https://zenquotes.io/api/today');
    
    if (!response.ok) {
      console.error('ZenQuotes API returned status:', response.status);
      throw new Error('External API unavailable');
    }

    const data = await response.json();
    console.log('Quote fetched successfully');
    
    // ZenQuotes returns array with format: [{ q: "quote", a: "author" }]
    const quote = data[0];
    
    return new Response(
      JSON.stringify({
        success: true,
        quote: quote.q,
        author: quote.a
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error fetching quote:', error instanceof Error ? error.message : 'Unknown error');
    
    // Fallback quote if API fails
    return new Response(
      JSON.stringify({
        success: true,
        quote: "The greatest glory in living lies not in never falling, but in rising every time we fall.",
        author: "Nelson Mandela",
        fallback: true
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

// Get allowed origins from environment or use defaults
const getAllowedOrigins = (): string[] => {
  const allowedOrigin = Deno.env.get('ALLOWED_ORIGIN');
  if (allowedOrigin) {
    return allowedOrigin.split(',').map(o => o.trim());
  }
  // Default to common Lovable domains
  return [
    'https://lovable.dev',
    'https://preview--usyakjyrgdqzsbbomcxe.lovable.app',
    'https://usyakjyrgdqzsbbomcxe.lovable.app',
  ];
};

const getCorsHeaders = (req: Request): Record<string, string> => {
  const origin = req.headers.get('Origin') || '';
  const allowedOrigins = getAllowedOrigins();
  
  // Check if origin is allowed
  const isAllowed = allowedOrigins.some(allowed => 
    origin === allowed || 
    origin.endsWith('.lovable.app') || 
    origin.endsWith('.lovable.dev')
  );
  
  return {
    'Access-Control-Allow-Origin': isAllowed ? origin : allowedOrigins[0],
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  };
};

// Country name to ISO code mapping
const COUNTRY_CODES: Record<string, string> = {
  'United States': 'USA',
  'Japan': 'JPN',
  'United Kingdom': 'GBR',
  'Germany': 'DEU',
  'France': 'FRA',
  'Canada': 'CAN',
  'Australia': 'AUS',
  'Spain': 'ESP',
  'Italy': 'ITA',
  'South Korea': 'KOR',
  'Brazil': 'BRA',
  'Mexico': 'MEX',
  'India': 'IND',
  'China': 'CHN',
  'Russia': 'RUS',
  'Netherlands': 'NLD',
  'Sweden': 'SWE',
  'Switzerland': 'CHE',
  'Norway': 'NOR',
  'Denmark': 'DNK',
  'Finland': 'FIN',
  'Belgium': 'BEL',
  'Austria': 'AUT',
  'Portugal': 'PRT',
  'Greece': 'GRC',
  'Poland': 'POL',
  'Czech Republic': 'CZE',
  'Hungary': 'HUN',
  'Ireland': 'IRL',
  'New Zealand': 'NZL',
  'Singapore': 'SGP',
  'Hong Kong': 'HKG',
  'Taiwan': 'TWN',
  'Thailand': 'THA',
  'Indonesia': 'IDN',
  'Philippines': 'PHL',
  'Vietnam': 'VNM',
  'Malaysia': 'MYS',
  'Turkey': 'TUR',
  'Israel': 'ISR',
  'United Arab Emirates': 'ARE',
  'Saudi Arabia': 'SAU',
  'South Africa': 'ZAF',
  'Nigeria': 'NGA',
  'Egypt': 'EGY',
  'Argentina': 'ARG',
  'Chile': 'CHL',
  'Colombia': 'COL',
  'Peru': 'PER',
};

// Fallback data if API fails (2022 data)
const FALLBACK_DATA: Record<string, { male: number; female: number }> = {
  'USA': { male: 74.8, female: 80.2 },
  'JPN': { male: 81.5, female: 87.6 },
  'GBR': { male: 79.0, female: 82.9 },
  'DEU': { male: 78.7, female: 83.4 },
  'FRA': { male: 79.5, female: 85.5 },
  'CAN': { male: 80.0, female: 84.1 },
  'AUS': { male: 81.3, female: 85.3 },
  'ESP': { male: 80.4, female: 85.8 },
  'ITA': { male: 80.5, female: 84.8 },
  'KOR': { male: 80.5, female: 86.5 },
  'BRA': { male: 72.0, female: 79.4 },
  'MEX': { male: 72.1, female: 77.8 },
  'IND': { male: 68.4, female: 70.7 },
  'CHN': { male: 75.0, female: 80.5 },
  'DEFAULT': { male: 73.0, female: 78.0 },
};

// Validate country input
const isValidCountry = (country: unknown): country is string => {
  if (typeof country !== 'string') return false;
  // Allow only alphanumeric, spaces, and common punctuation
  return /^[a-zA-Z\s\-']{1,100}$/.test(country);
};

async function fetchFromWorldBank(countryCode: string, indicator: string): Promise<number | null> {
  try {
    // World Bank API - get most recent data
    const url = `https://api.worldbank.org/v2/country/${encodeURIComponent(countryCode)}/indicator/${encodeURIComponent(indicator)}?format=json&date=2020:2023&per_page=5`;
    console.log('Fetching from World Bank for country:', countryCode);
    
    const response = await fetch(url);
    if (!response.ok) {
      console.error('World Bank API returned status:', response.status);
      return null;
    }
    
    const data = await response.json();
    
    // World Bank returns [metadata, data_array]
    if (!data[1] || data[1].length === 0) {
      console.log('No data found for', countryCode, indicator);
      return null;
    }
    
    // Find the most recent non-null value
    for (const entry of data[1]) {
      if (entry.value !== null) {
        console.log(`Found value for ${countryCode}: ${entry.value} (${entry.date})`);
        return entry.value;
      }
    }
    
    return null;
  } catch (error) {
    console.error('Error fetching from World Bank:', error instanceof Error ? error.message : 'Unknown error');
    return null;
  }
}

serve(async (req) => {
  const corsHeaders = getCorsHeaders(req);
  
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Parse request body
    let body: unknown;
    try {
      body = await req.json();
    } catch {
      return new Response(
        JSON.stringify({
          success: false,
          error: 'Invalid request format',
          male: FALLBACK_DATA['DEFAULT'].male,
          female: FALLBACK_DATA['DEFAULT'].female,
        }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const country = (body as Record<string, unknown>)?.country;
    
    // Validate country input
    if (!isValidCountry(country)) {
      console.warn('Invalid country format received');
      return new Response(
        JSON.stringify({
          success: true,
          country: 'Unknown',
          countryCode: 'DEFAULT',
          male: FALLBACK_DATA['DEFAULT'].male,
          female: FALLBACK_DATA['DEFAULT'].female,
          source: 'fallback',
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('Getting life expectancy for country:', country);
    
    const countryCode = COUNTRY_CODES[country] || 'USA';
    
    // World Bank indicators for life expectancy by gender
    // SP.DYN.LE00.MA.IN = Male life expectancy at birth
    // SP.DYN.LE00.FE.IN = Female life expectancy at birth
    
    const [maleLE, femaleLE] = await Promise.all([
      fetchFromWorldBank(countryCode, 'SP.DYN.LE00.MA.IN'),
      fetchFromWorldBank(countryCode, 'SP.DYN.LE00.FE.IN'),
    ]);
    
    // Use fallback if API data not available
    const fallbackData = FALLBACK_DATA[countryCode] || FALLBACK_DATA['DEFAULT'];
    
    const result = {
      success: true,
      country,
      countryCode,
      male: maleLE !== null ? Math.round(maleLE * 10) / 10 : fallbackData.male,
      female: femaleLE !== null ? Math.round(femaleLE * 10) / 10 : fallbackData.female,
      source: maleLE !== null && femaleLE !== null ? 'World Bank' : 'fallback',
    };
    
    console.log('Life expectancy result for:', country);
    
    return new Response(
      JSON.stringify(result),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error processing request:', error instanceof Error ? error.message : 'Unknown error');
    
    return new Response(
      JSON.stringify({
        success: false,
        error: 'Unable to retrieve data. Please try again.',
        male: FALLBACK_DATA['DEFAULT'].male,
        female: FALLBACK_DATA['DEFAULT'].female,
      }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

// Get allowed origins from environment or use defaults
const getAllowedOrigins = (): string[] => {
  const allowedOrigin = Deno.env.get('ALLOWED_ORIGIN');
  if (allowedOrigin) {
    return allowedOrigin.split(',').map(o => o.trim());
  }
  // Default to common Lovable domains
  return [
    'https://lovable.dev',
    'https://preview--usyakjyrgdqzsbbomcxe.lovable.app',
    'https://usyakjyrgdqzsbbomcxe.lovable.app',
  ];
};

const getCorsHeaders = (req: Request): Record<string, string> => {
  const origin = req.headers.get('Origin') || '';
  const allowedOrigins = getAllowedOrigins();
  
  // Check if origin is allowed
  const isAllowed = allowedOrigins.some(allowed => 
    origin === allowed || 
    origin.endsWith('.lovable.app') || 
    origin.endsWith('.lovable.dev')
  );
  
  return {
    'Access-Control-Allow-Origin': isAllowed ? origin : allowedOrigins[0],
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  };
};

// Validate invite code format: exactly 8 characters from allowed set
const isValidInviteCode = (code: unknown): code is string => {
  if (typeof code !== 'string') return false;
  // Match the character set used in generateInviteCode
  const validPattern = /^[A-HJ-NP-Za-hj-np-z2-9]{8}$/;
  return validPattern.test(code);
};

Deno.serve(async (req) => {
  const corsHeaders = getCorsHeaders(req);
  
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    
    // Create admin client for operations that need to bypass RLS
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey);
    
    // Get the authorization header to identify the accepting user
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Authentication required' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Create client with user's token
    const supabaseClient = createClient(supabaseUrl, Deno.env.get('SUPABASE_ANON_KEY')!, {
      global: { headers: { Authorization: authHeader } }
    });

    // Get the current user
    const { data: { user }, error: userError } = await supabaseClient.auth.getUser();
    if (userError || !user) {
      console.error('User authentication failed:', userError?.message);
      return new Response(
        JSON.stringify({ error: 'Authentication required' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Parse and validate request body
    let body: unknown;
    try {
      body = await req.json();
    } catch {
      return new Response(
        JSON.stringify({ error: 'Invalid request format' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const inviteCode = (body as Record<string, unknown>)?.inviteCode;
    
    // Validate invite code format
    if (!isValidInviteCode(inviteCode)) {
      console.warn('Invalid invite code format attempted:', typeof inviteCode);
      return new Response(
        JSON.stringify({ error: 'Invalid invitation code format' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('Processing invitation acceptance for user:', user.id);

    // Get the invitation using admin client
    const { data: invitation, error: inviteError } = await supabaseAdmin
      .from('family_invitations')
      .select('*, family_members(*)')
      .eq('invite_code', inviteCode)
      .eq('status', 'pending')
      .single();

    if (inviteError || !invitation) {
      console.error('Invitation lookup failed:', inviteError?.code);
      return new Response(
        JSON.stringify({ error: 'Invalid or expired invitation' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check if invitation has expired
    if (new Date(invitation.expires_at) < new Date()) {
      await supabaseAdmin
        .from('family_invitations')
        .update({ status: 'expired' })
        .eq('id', invitation.id);
      
      return new Response(
        JSON.stringify({ error: 'Invitation has expired' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Can't accept your own invitation
    if (invitation.inviter_user_id === user.id) {
      return new Response(
        JSON.stringify({ error: 'You cannot accept your own invitation' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('Creating connections for invitation:', invitation.id);

    // Update invitation status
    const { error: updateError } = await supabaseAdmin
      .from('family_invitations')
      .update({ 
        status: 'accepted',
        accepted_by_user_id: user.id,
        accepted_at: new Date().toISOString()
      })
      .eq('id', invitation.id);

    if (updateError) {
      console.error('Failed to update invitation status:', updateError.code);
      throw new Error('Failed to process invitation');
    }

    // Create bidirectional family connections
    const { error: conn1Error } = await supabaseAdmin
      .from('family_connections')
      .insert({
        user_id: invitation.inviter_user_id,
        connected_user_id: user.id,
        invitation_id: invitation.id
      });

    if (conn1Error && !conn1Error.message.includes('duplicate')) {
      console.error('Connection creation failed:', conn1Error.code);
      throw new Error('Failed to create connection');
    }

    const { error: conn2Error } = await supabaseAdmin
      .from('family_connections')
      .insert({
        user_id: user.id,
        connected_user_id: invitation.inviter_user_id,
        invitation_id: invitation.id
      });

    if (conn2Error && !conn2Error.message.includes('duplicate')) {
      console.error('Connection creation failed:', conn2Error.code);
      throw new Error('Failed to create connection');
    }

    // Share the family member with the accepting user
    const { error: shareError } = await supabaseAdmin
      .from('shared_family_members')
      .insert({
        family_member_id: invitation.family_member_id,
        shared_with_user_id: user.id,
        invitation_id: invitation.id
      });

    if (shareError && !shareError.message.includes('duplicate')) {
      console.error('Share operation failed:', shareError.code);
      throw new Error('Failed to share family member');
    }

    // Create a reciprocal family member for the inviter in the accepting user's family
    // This represents the accepting user in the inviter's family view
    const acceptingUserProfile = await supabaseAdmin
      .from('profiles')
      .select('full_name')
      .eq('id', user.id)
      .single();

    // Get the inviter's profile to create a family member for the accepting user
    const inviterProfile = await supabaseAdmin
      .from('profiles')
      .select('full_name')
      .eq('id', invitation.inviter_user_id)
      .single();

    // Create a family member entry for the accepting user representing the inviter
    const { data: newFamilyMember, error: createFmError } = await supabaseAdmin
      .from('family_members')
      .insert({
        user_id: user.id,
        name: inviterProfile.data?.full_name || 'Family Member',
        relation: 'family', // Generic relation, user can update later
      })
      .select()
      .single();

    if (createFmError) {
      console.error('Create family member failed:', createFmError.code);
      // Non-fatal, continue
    } else if (newFamilyMember) {
      // Share this new family member back with the inviter
      await supabaseAdmin
        .from('shared_family_members')
        .insert({
          family_member_id: newFamilyMember.id,
          shared_with_user_id: invitation.inviter_user_id,
          invitation_id: invitation.id
        });
    }

    console.log('Invitation accepted successfully');

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Invitation accepted! You are now connected.',
        familyMember: invitation.family_members
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: unknown) {
    console.error('Error accepting invitation:', error instanceof Error ? error.message : 'Unknown error');
    return new Response(
      JSON.stringify({ error: 'Unable to process invitation. Please try again.' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
